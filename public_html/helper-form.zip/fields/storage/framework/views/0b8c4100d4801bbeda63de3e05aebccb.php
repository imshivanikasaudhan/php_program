<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <h2 class="text-xl font-medium leading-tight">
                <?php echo e(__('User List')); ?>

            </h2>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="grid grid-cols-12 gap-6">
        <div class="relative overflow-x-auto shadow-md sm:rounded-lg col-span-12">
            <table class="w-full text-base text-left text-gray-500 dark:text-gray-300">
                <thead class="text-sm text-gray-700 dark:text-gray-400 capitalize bg-gray-50 dark:bg-dark-eval-1">
                    <tr>
                        <th scope="col" class="px-6 py-3">Name</th>
                        <th scope="col" class="px-6 py-3">Phone</th>
                        <th scope="col" class="px-6 py-3">User Name</th>
                        <th scope="col" class="px-6 py-3">Count</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="bg-white border-b hover:bg-gray-50 capitalize dark:bg-dark-eval-1 font-secondary">
                            <th class="px-6 py-4 font-medium text-black dark:text-white whitespace-nowrap font-primary"><?php echo $user->name; ?> </th>
                            <td class="px-6 py-4"><?php echo e($user->phone); ?></td>
                            <td class="px-6 py-4"><?php echo $user->username; ?></td>
                            <td class="px-6 py-4"><?php echo e($user->providers); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /home/helperadda/public_html/fields/resources/views/user/list.blade.php ENDPATH**/ ?>