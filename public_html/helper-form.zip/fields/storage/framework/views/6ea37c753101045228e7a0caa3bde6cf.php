<svg aria-hidden="true" class="w-6 h-6 lg:hidden" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" aria-hidden="true">
  <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
</svg><?php /**PATH /home/helperadda/public_html/fields/storage/framework/views/d6bcc263d088c149dcd29c54fe76f240.blade.php ENDPATH**/ ?>