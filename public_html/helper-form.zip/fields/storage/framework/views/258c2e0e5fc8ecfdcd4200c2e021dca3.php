<footer class="flex-shrink-0 px-6 py-4">
</footer>
<?php /**PATH /home/ccxkoxym/scriptkart.in/haform/resources/views/components/footer.blade.php ENDPATH**/ ?>