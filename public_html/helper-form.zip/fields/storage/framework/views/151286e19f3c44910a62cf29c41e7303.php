<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <h2 class="text-xl font-medium leading-tight">
                <?php echo e(__('Service Providers')); ?>

            </h2>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="grid grid-cols-12 gap-6">
        <div class="col-span-12 my-4">
            <label for="username" class="block font-medium text-lg">Filter By User</label>
            <select id="username" class="p-4 rounded-md bg-gray-300 border-0 w-full text-base dark:bg-white dark:text-black">
                <option value="all" <?php echo e(in_array($username, ['all', '']) ? 'selected' : ''); ?>>All</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->username); ?>" <?php echo e($username == $user->username ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-span-12">
            <div class="grid grid-cols-12 gap-4 pt-5">
                <div class="relative overflow-x-auto shadow-md sm:rounded-lg col-span-12">
                    <table class="w-full text-base text-left text-gray-500 dark:text-gray-300">
                        <thead class="text-sm text-gray-700 dark:text-gray-400 capitalize bg-gray-50 dark:bg-dark-eval-1">
                            <tr>
                                <th scope="col" class="px-6 py-3">Name</th>
                                <th scope="col" class="px-6 py-3">Father's/Husband's Name</th>
                                <th scope="col" class="px-6 py-3">DOB</th>
                                <th scope="col" class="px-6 py-3">Contact</th>
                                <th scope="col" class="px-6 py-3">Address</th>
                                <th scope="col" class="px-6 py-3">Nationality</th>
                                <th scope="col" class="px-6 py-3">Govt Ids</th>
                                <th scope="col" class="px-6 py-3">Services</th>
                                <th scope="col" class="px-6 py-3">Image</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $serviceProviders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="bg-white border-b hover:bg-gray-50 capitalize dark:bg-dark-eval-1 font-secondary">
                                    <th class="px-6 py-4 font-medium text-black dark:text-white whitespace-nowrap"><?php echo $agent->name; ?></th>
                                    <td class="px-6 py-4"><?php echo e($agent->father_name); ?></td>
                                    <td class="px-6 py-4"><?php echo e($agent->dob); ?></td>
                                    <td class="px-6 py-4"><?php echo e($agent->phone); ?>, <?php echo $agent->alternate_phone; ?></td>
                                    <td class="px-6 py-4"><?php echo e($agent->address); ?></td>
                                    <td class="px-6 py-4"><?php echo e($agent->nationality); ?></td>
                                    <td class="px-6 py-4">
                                        <span class="font-bold text-base">PAN:</span> <?php echo e($agent->pan); ?> <br>
                                        <span class="font-bold text-base">Aadhar:</span> <?php echo e($agent->aadhar); ?></td>
                                    <td class="px-6 py-4"><?php echo e($agent->services); ?></td>
                                    <td class="px-6 py-4"><img src="<?php echo e(asset('img/uploads/' . $agent->image)); ?>" alt="<?php echo $agent->name; ?>" class="w-40 rounded-md"></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/helperadda/public_html/fields/resources/views/service/list.blade.php ENDPATH**/ ?>