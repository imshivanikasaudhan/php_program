<footer class="flex-shrink-0 px-6 py-4">
</footer>
<?php /**PATH /Users/vasudev/projects/ha/form-dashboard/resources/views/components/footer.blade.php ENDPATH**/ ?>