<footer class="flex-shrink-0 px-6 py-4">
</footer>
<?php /**PATH /home/helperadda/public_html/fields/resources/views/components/footer.blade.php ENDPATH**/ ?>