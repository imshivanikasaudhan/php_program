<footer class="flex-shrink-0 px-6 py-4">
</footer>
